Project created with Create React App

You will have to get the Google Maps keys and OpenWeather Map keys.

<img width="540" alt="Screen Shot 2019-12-22 at 10 40 09 PM" src="https://user-images.githubusercontent.com/18078687/71336371-76220e00-250c-11ea-8029-9e8da7531bd9.png">
