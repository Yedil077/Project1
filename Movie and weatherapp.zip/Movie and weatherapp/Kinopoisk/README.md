# Kinopoisk

## Description
Website developed within the framework of the front-end training in the React module. Page to search for movie information and trends via The Movie Data Base Api

## Why
Learning to use the router in react

## Stack
Movies App with "The Movie Database API" - Developed with React
